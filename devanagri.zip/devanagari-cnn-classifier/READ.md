 Dataset: Devanagari Handwritten Character Dataset
-  Model: 2 Conv2D layers + MaxPooling + Dense
-  Accuracy: ~97.6% validation accuracy